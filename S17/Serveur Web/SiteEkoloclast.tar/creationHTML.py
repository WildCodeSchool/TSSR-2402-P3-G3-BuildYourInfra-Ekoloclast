import csv

# Chemin vers le fichier CSV des utilisateurs
fichier_csv = r"C:\Users\Nico\TSSR\Projet3\HTML\HTML-Ekoloclast.csv"

# Nombre total d'avatars disponibles
nombre_avatars = 30

# Liste pour stocker les données des utilisateurs
utilisateurs = []

# Lire le fichier CSV et charger les données dans la liste utilisateurs
with open(fichier_csv, newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile, delimiter=';')
    for row in reader:
        utilisateurs.append(row)

# Créer le contenu de la page principale HTML avec le titre, la description et la barre de recherche
page_principale_html = f"""
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ekoloclast - Le Futur de demain est aujourd'hui</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f9eb; /* Fond vert clair */
        }}
        .container {{
            max-width: 800px;
            margin: auto;
            padding: 20px;
            background-color: #ffffff; /* Fond blanc pour le contenu */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Ombre légère */
            border-radius: 8px; /* Coins arrondis */
        }}
        .search-bar {{
            margin-bottom: 20px;
        }}
        .user-list {{
            list-style-type: none;
            padding: 0;
        }}
        .user-list li {{
            margin-bottom: 10px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Ekoloclast - Le Futur de demain est aujourd'hui</h1>
        <p>Ceci est un annuaire.</p>
        
        <div class="search-bar">
            <label for="search-input">Rechercher un nom :</label>
            <input type="text" id="search-input" placeholder="Entrez un nom...">
            <button onclick="searchUsers()">Rechercher</button>
        </div>
        
        <ul class="user-list">
"""

# Générer les éléments de liste pour chaque utilisateur
for index, utilisateur in enumerate(utilisateurs):
    prenom = utilisateur["Prenom"]
    nom = utilisateur["Nom"]
    nom_complet = f"{prenom}_{nom}"

    # Ajouter chaque utilisateur à la liste avec un lien vers sa page individuelle
    page_principale_html += f'            <li><a href="{nom_complet}.html">{prenom} {nom}</a></li>\n'

# Terminer le contenu de la page principale HTML
page_principale_html += """
        </ul>
    </div>
    
    <script>
        function searchUsers() {
            var input = document.getElementById('search-input').value.toLowerCase();
            var userList = document.getElementsByClassName('user-list')[0];
            var users = userList.getElementsByTagName('li');
            
            for (var i = 0; i < users.length; i++) {
                var userName = users[i].innerText.toLowerCase();
                if (userName.includes(input)) {
                    users[i].style.display = '';
                } else {
                    users[i].style.display = 'none';
                }
            }
        }
    </script>
</body>
</html>
"""

# Écrire le contenu dans le fichier HTML pour la page principale
with open("page_principale.html", "w", encoding="utf-8") as f:
    f.write(page_principale_html)

print("Page principale HTML créée avec succès.")

# Générer les pages HTML pour chaque utilisateur
for index, utilisateur in enumerate(utilisateurs):
    prenom = utilisateur["Prenom"]
    nom = utilisateur["Nom"]
    nom_complet = f"{prenom}_{nom}"
    mail = utilisateur["Mail"]
    telephone_fixe = utilisateur["Telephone fixe"]
    telephone_portable = utilisateur["Telephone portable"]

    # Sélectionner l'avatar en faisant un roulement
    numero_avatar = (index % nombre_avatars) + 1
    avatar_filename = f"avataaars ({numero_avatar}).png"

    # Créer le contenu de la page HTML pour l'utilisateur
    page_utilisateur_html = f"""
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>{prenom} {nom}</title>
</head>
<body>
    <h1>{prenom} {nom}</h1>
    <img src="{avatar_filename}" alt="Avatar de {prenom} {nom}">
    <p>Société : {utilisateur["Societe"]}</p>
    <p>Département : {utilisateur["Departement"]}</p>
    <p>Service : {utilisateur["Service"]}</p>
    <p>Fonction : {utilisateur["fonction"]}</p>
    <p>Date de naissance : {utilisateur["Date de naissance"]}</p>
    <p>Mail : <a href="mailto:{mail}">{mail}</a></p>
    <p>Téléphone fixe : <a href="tel:{telephone_fixe}">{telephone_fixe}</a></p>
    <p>Téléphone portable : <a href="tel:{telephone_portable}">{telephone_portable}</a></p>
    <p><a href="page_principale.html">Retour à la liste des utilisateurs</a></p>
</body>
</html>
"""

    # Écrire le contenu dans le fichier HTML pour l'utilisateur
    with open(f"{nom_complet}.html", "w", encoding="utf-8") as f:
        f.write(page_utilisateur_html)

    # Ajouter chaque utilisateur à la liste avec un lien vers sa page individuelle
    page_principale_html += f'        <li><a href="{nom_complet}.html">{prenom} {nom}</a></li>\n'

# Terminer le contenu de la page principale HTML
page_principale_html += """
    </ul>
</body>
</html>
"""

# Écrire le contenu dans le fichier HTML pour la page principale
with open("page_principale.html", "w", encoding="utf-8") as f:
    f.write(page_principale_html)

print("Pages HTML créées avec succès.")
